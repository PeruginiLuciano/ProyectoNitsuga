import 'package:get/get.dart';

class Protection {
  var turnOffWaterPumper = false.obs;
  var closeFloodgateGreyWater = false.obs;
  var closeFloodgateBlackWater = false.obs;
  var automaticStartGenerator = false.obs;
}