enum ChannelMethod {
  open, close, read, write
}