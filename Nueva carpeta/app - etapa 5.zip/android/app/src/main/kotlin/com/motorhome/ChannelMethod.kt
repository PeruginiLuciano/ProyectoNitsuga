package com.motorhome

enum class ChannelMethod {
    OPEN, CLOSE, READ, WRITE
}